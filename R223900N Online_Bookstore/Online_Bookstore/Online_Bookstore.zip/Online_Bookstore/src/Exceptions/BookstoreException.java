package Exceptions;

public class BookstoreException extends RuntimeException{

}
